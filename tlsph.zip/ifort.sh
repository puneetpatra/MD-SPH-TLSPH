ifort -c *.f90 -traceback -fpe0
ifort -o result *.o
./result
